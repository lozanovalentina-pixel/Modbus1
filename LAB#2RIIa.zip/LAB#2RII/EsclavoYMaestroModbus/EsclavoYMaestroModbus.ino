#include <ModbusRtu.h>

// ---------------------------------------------------------
// PINES DEL ESP32 PARA EL MODULO MAX485
// ---------------------------------------------------------
#define MAX485_RX 16   // RO del MAX485
#define MAX485_TX 17   // DI del MAX485
#define MAX485_RE_DE 4 // PINES RE y DE unidos al pin 4

#define SLAVE_ID 3     // Cambiar para cada ESP32 (del 2 al 7)

// ---------------------------------------------------------
// VECTOR DE REGISTROS MODBUS
// ---------------------------------------------------------
// La librería de smarmengol vincula directamente las peticiones Modbus a este 
// vector. El registro 0 será au16data[0], el registro 1 será au16data[1], etc.
// En el PMAC770, los voltajes L1, L2 y L3 están en los primeros 6 registros.
uint16_t au16data[6]; 

// Crear instancia del Esclavo Modbus (ID, Puerto, Pin Control TX/RX)
Modbus slave(SLAVE_ID, Serial2, MAX485_RE_DE);

void setup() {
  Serial.begin(115200);
  while (!Serial);

  Serial.println("============================================");
  Serial.printf(" Iniciando ESP32 como ESCLAVO SIMULADOR (Smarmengol) (ID: %d)\n", SLAVE_ID);
  Serial.println("============================================");

  // En ESP32 es necesario inicializar Serial2 antes con sus pines RX/TX
  Serial2.begin(9600, SERIAL_8N1, MAX485_RX, MAX485_TX);

  // Iniciar la comunicación Modbus en la librería
  slave.start();
}

void loop() {
  // ---------------------------------------------------------
  // 1. GENERAR VOLTAJES FALSOS / DINÁMICOS
  // ---------------------------------------------------------
  // Vamos a generar voltajes que varíen ligeramente (alrededor de 220.5 V)
  // El PMAC usa números multiplicados por 10 (2205) y divididos en 2 registros de 16bit.
  
  uint32_t fake_v1 = 2200 + (millis() % 20); // Fluctuará entre 220.0 y 221.9
  uint32_t fake_v2 = 2195 + (millis() % 15);
  uint32_t fake_v3 = 2210 + (millis() % 10);

  // Llenar el arreglo au16data para Voltaje L1
  au16data[0] = (fake_v1 >> 16) & 0xFFFF; // High Word
  au16data[1] = fake_v1 & 0xFFFF;         // Low Word

  // Llenar para Voltaje L2
  au16data[2] = (fake_v2 >> 16) & 0xFFFF;
  au16data[3] = fake_v2 & 0xFFFF;

  // Llenar para Voltaje L3
  au16data[4] = (fake_v3 >> 16) & 0xFFFF;
  au16data[5] = fake_v3 & 0xFFFF;

  // ---------------------------------------------------------
  // 2. ATENDER PETICIONES DE LA PC (ESCLAVO)
  // ---------------------------------------------------------
  // Esto escucha el bus RS485. Si la PC hace una pregunta por los registros 
  // del 0 al 5, la librería automáticamente responde devolviendo 'au16data'.
  // Al pasarle '6', permitimos leer/escribir hasta el índice máximo 5.
  
  slave.poll(au16data, 6);
}