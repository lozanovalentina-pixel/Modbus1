#include <ModbusMaster.h>

// ---------------------------------------------------------
// PINES DEL ESP32 PARA EL MODULO MAX485
// ---------------------------------------------------------
#define MAX485_RX 16   // RO del MAX485
#define MAX485_TX 17   // DI del MAX485
#define MAX485_RE_DE 4 // PINES RE y DE unidos al pin 4

// Instancia de ModbusMaster
ModbusMaster node;

// Timer para que el loop no se bloquee y podamos leer el Monitor Serial
unsigned long ultimo_scan = 0;
const unsigned long INTERVALO_SCAN = 5000; // 5 segundos

// Funciones de control de flujo Half-Duplex (necesarias para MAX485)
void preTransmission() {
  digitalWrite(MAX485_RE_DE, 1); // Poner en modo Transmisión (TX)
}

void postTransmission() {
  digitalWrite(MAX485_RE_DE, 0); // Poner en modo Recepción (RX)
}

void setup() {
  // Inicializar consola para debug (Cable USB al PC)
  Serial.begin(115200);
  while (!Serial) {
    ;
  }

  Serial.println("============================================");
  Serial.println("  Iniciando Lector Modbus ESP32 - PMAC770   ");
  Serial.println("============================================");

  // Configurar pin de control RS485
  pinMode(MAX485_RE_DE, OUTPUT);
  digitalWrite(MAX485_RE_DE, 0); // Iniciar en modo RX

  // Inicializar puerto Serial2 para el MAX485 (baudrate 9600, 8N1)
  Serial2.begin(9600, SERIAL_8N1, MAX485_RX, MAX485_TX);

  // Inicializar el esclavo Modbus: ID 4
  node.begin(4, Serial2);

  // Registrar las funciones de cambio TX/RX
  node.preTransmission(preTransmission);
  node.postTransmission(postTransmission);
}

// ---------------------------------------------------------
// FUNCIÓN PARA LEER VOLTAJES
// ---------------------------------------------------------
void leerVoltajes() {
  uint8_t result;

  // Leer 6 registros (30001 al 30006, offset 0 a 5)
  // Nota: Aunque la guía dice 30001 (Input Registers -> Función 4),
  // muchos PMAC exigen leerlos como Holding Registers (Función 3).
  // Probaremos con Función 3 (readHoldingRegisters). Si da error,
  // cámbialo a readInputRegisters.
  result = node.readHoldingRegisters(0, 6);

  if (result == node.ku8MBSuccess) {
    // Reconstruir los valores de 32 bits (2 registros de 16 bits)
    // El orden depende del PMAC, usualmente High-Word primero
    uint32_t raw_v1 =
        (node.getResponseBuffer(0) << 16) | node.getResponseBuffer(1);
    uint32_t raw_v2 =
        (node.getResponseBuffer(2) << 16) | node.getResponseBuffer(3);
    uint32_t raw_v3 =
        (node.getResponseBuffer(4) << 16) | node.getResponseBuffer(5);

    // Aplicar la escala de 0.1
    float v1 = raw_v1 * 0.1;
    float v2 = raw_v2 * 0.1;
    float v3 = raw_v3 * 0.1;

    Serial.printf("Voltajes -> L1: %.1f V | L2: %.1f V | L3: %.1f V\n", v1, v2,
                  v3);
  } else {
    Serial.printf("Error leyendo voltajes. Codigo: 0x%02X\n", result);
  }
}

// ---------------------------------------------------------
// FUNCIÓN PARA LEER LA DIRECCIÓN MODBUS (Para confirmar la config)
// ---------------------------------------------------------
void leerConfiguracion() {
  uint8_t result;

  // Leer registro 5003 (0x138B) - Slave Address
  result = node.readHoldingRegisters(5003, 1);

  if (result == node.ku8MBSuccess) {
    uint16_t direccion = node.getResponseBuffer(0);
    Serial.printf("DIRECCION ESCLAVO ACTUAL: %d\n", direccion);
  } else {
    Serial.printf("Error leyendo configuracion. Codigo: 0x%02X\n", result);
  }
}

// ---------------------------------------------------------
// FUNCIÓN DE ESCRITURA ESPECIAL (FC16 obligatoria para PMAC770)
// ---------------------------------------------------------
void cambiarDireccionModbus(uint16_t nueva_direccion) { ///*
  uint8_t result;

  Serial.printf("Intentando cambiar direccion Modbus a %d...\n",
                nueva_direccion);

  // Limpiar buffer de transmision
  node.clearTransmitBuffer();

  // Cargar el valor que queremos escribir (en la posicion 0 del buffer)
  node.setTransmitBuffer(0, nueva_direccion);

  // Escribir usando FC16 (Write Multiple Registers), incluso si es solo 1
  // registro Dirección Modbus = 5003 (0x138B). Cantidad de registros = 1
  result = node.writeMultipleRegisters(5003, 4);

  if (result == node.ku8MBSuccess) {
    Serial.println("¡EXITO! Nueva direccion guardada.");
    Serial.println("Recuerda reiniciar el ESP32 o actualizar node.begin() con "
                   "el nuevo ID.");
  } else {
    Serial.printf("Error al escribir. Codigo: 0x%02X\n", result);
  }
} //*/ 

void loop() {
  // =========================================================
  // 1. ESCUCHAR AL USUARIO POR EL MONITOR SERIAL (Interactivo)
  // =========================================================
  // Si tipeaste un número en la consola de Arduino y presionaste Enter:
  if (Serial.available() > 0) {
    String entrada = Serial.readStringUntil('\n');
    entrada.trim(); // Limpiar espacios invisibles

    if (entrada.length() > 0) {
      int nueva_dir = entrada.toInt();

      // Validar que sea una dirección Modbus real (1 a 247)
      if (nueva_dir > 0 && nueva_dir <= 247) {
        Serial.println("\n>>> ORDEN DEL USUARIO RECIBIDA <<<");
        cambiarDireccionModbus(nueva_dir);

        // Vuelve a amarrar a nuestro ESP32 a la nueva direccion para
        // no perder comunicacion en las lecturas siguientes
        node.begin(nueva_dir, Serial2);
        Serial.printf(
            "ESP32 reconfigurado para hablarle permanentemente al ID: %d\n\n",
            nueva_dir);
      } else {
        Serial.println("Entrada invalida. Ingresa un numero del 1 al 247.");
      }
    }
  }

  // =========================================================
  // 2. LECTURAS PERIODICAS (Sin bloquear el programa)
  // =========================================================
  if (millis() - ultimo_scan >= INTERVALO_SCAN) {
    ultimo_scan = millis(); // Resetear cronómetro

    // Leer Configuración
    leerConfiguracion();

    // REGLA DE ORO EN RS-485: Darle un respiro al bus entre mensajes.
    // El ESP32 es tan veloz que le dispara la segunda pregunta antes de que
    // el medidor termine de soltar el canal, causando el Timeout (0xE2).
    delay(100);

    // Leer Mediciones (Voltajes)
    leerVoltajes();

    Serial.println("--------------------------------------------");
    Serial.println("- TIPEA UN NUMERO ARRIBA Y PRESIONA ENTER PARA CAMBIAR EL "
                   "ID DEL MEDIDOR -");
  }
}