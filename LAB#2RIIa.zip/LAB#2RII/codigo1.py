import sys
import time
from pymodbus.client import ModbusSerialClient

def read_pymodbus(port, slave_id, register_address, count=10):
    # Configurar el cliente para pymodbus
    client = ModbusSerialClient(
        port=port,
        baudrate=9600,
        bytesize=8,
        parity='N',
        stopbits=1,
        timeout=1
    )

    print(f"[{time.strftime('%H:%M:%S')}] Conectando a {port} — Esclavo {slave_id} a 9600 bps...")

    # Conectar una sola vez antes del bucle (CORRECCIÓN: evita resource leak)
    if not client.connect():
        print(f"[{time.strftime('%H:%M:%S')}] No se pudo abrir {port}. Verifica si está ocupado o desconectado.")
        sys.exit(1)

    print(f"[{time.strftime('%H:%M:%S')}] Puerto abierto. Iniciando lectura continua (PYMODBUS — Fn3 Holding Registers).")
    print(f"[{time.strftime('%H:%M:%S')}] Leyendo {count} registro(s) desde dirección {register_address}. Ctrl+C para detener.\n")

    # try/finally garantiza que el puerto se cierre siempre (CORRECCIÓN)
    try:
        while True:
            try:
                result = client.read_holding_registers(
                    address=register_address,
                    count=count,
                    device_id=slave_id   # pymodbus 3.12.x usa device_id en lugar de slave
                )

                if not result.isError():
                    print(f"[{time.strftime('%H:%M:%S')}] --- LECTURA EXITOSA ---")
                    for i, valor in enumerate(result.registers):  # CORRECCIÓN: imprime todos
                        print(f"   Registro {register_address + i:>4} (0x{register_address + i:04X}): {valor}")
                    print()
                else:
                    print(f"[{time.strftime('%H:%M:%S')}] El esclavo {slave_id} no responde... (cable RS-485 o dirección incorrecto)")

            except Exception as e:
                print(f"[{time.strftime('%H:%M:%S')}] Error inesperado en el bus: {e}. Reintentando...")

            time.sleep(1)  # Retardo para no saturar el bus RS-485

    except KeyboardInterrupt:
        print(f"\n[{time.strftime('%H:%M:%S')}] Lectura detenida por el usuario.")
    finally:
        client.close()  # CORRECCIÓN: el puerto siempre se cierra
        print(f"[{time.strftime('%H:%M:%S')}] Puerto {port} cerrado.")

if __name__ == "__main__":
    # Valores por defecto según tu setup: COM4, esclavo 4, desde registro 0x0000
    port            = sys.argv[1] if len(sys.argv) > 1 else "COM4"
    slave_id        = int(sys.argv[2]) if len(sys.argv) > 2 else 4
    reg_address     = int(sys.argv[3], 0) if len(sys.argv) > 3 else 0  # acepta hex (0x..) y decimal
    count           = int(sys.argv[4]) if len(sys.argv) > 4 else 10

    print(f"Uso: python codigo1.py [PUERTO] [ID_ESCLAVO] [DIR_REGISTRO] [CANT_REGISTROS]")
    print(f"Ejecutando con: puerto={port}, esclavo={slave_id}, registro=0x{reg_address:04X}, count={count}\n")

    read_pymodbus(port, slave_id, reg_address, count)
