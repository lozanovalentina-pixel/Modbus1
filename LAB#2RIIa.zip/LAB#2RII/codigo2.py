import sys
import time
from pymodbus.client import ModbusSerialClient

def write_pymodbus(port, slave_id, register_address, value):
    # Validar rango de registro de 16 bits (CORRECCIÓN: evita error interno pymodbus)
    if not (0 <= value <= 65535):
        print(f"Error: el valor {value} está fuera del rango Modbus [0 - 65535].")
        sys.exit(1)

    # Configurar el cliente pymodbus
    client = ModbusSerialClient(
        port=port,
        baudrate=9600,
        bytesize=8,
        parity='N',
        stopbits=1,
        timeout=1
    )

    print(f"[{time.strftime('%H:%M:%S')}] Conectando a {port} — Esclavo {slave_id} (PYMODBUS)...")

    if client.connect():
        try:
            # PMAC770 solo soporta Función 16 (Write Multiple Registers) para escribir
            result = client.write_registers(
                address=register_address,
                values=[value],
                device_id=slave_id
            )

            if not result.isError():
                print(f"[{time.strftime('%H:%M:%S')}] [ÉXITO] Valor {value} escrito en registro {register_address} (0x{register_address:04X}).")
            else:
                print(f"[{time.strftime('%H:%M:%S')}] Error al escribir — el esclavo no respondió: {result}")

        except Exception as e:
            print(f"[{time.strftime('%H:%M:%S')}] Excepción durante la transmisión: {e}")  # CORRECCIÓN: typo "transmición"

        finally:
            client.close()
            print(f"[{time.strftime('%H:%M:%S')}] Puerto {port} cerrado.")
    else:
        print(f"[{time.strftime('%H:%M:%S')}] Error de conexión: No se pudo abrir {port}.")
        sys.exit(1)

if __name__ == "__main__":
    # Valores por defecto según tu setup: COM4, esclavo 4
    port                = sys.argv[1] if len(sys.argv) > 1 else "COM4"
    slave_id            = int(sys.argv[2]) if len(sys.argv) > 2 else 4
    register_address    = int(sys.argv[3], 0) if len(sys.argv) > 3 else 0   # acepta 0x.. y decimal
    valor               = int(sys.argv[4]) if len(sys.argv) > 4 else None

    if valor is None:
        print("Uso: python codigo2.py [PUERTO] [ID_ESCLAVO] [DIRECCION_REGISTRO] <VALOR>")
        print("Ejemplo: python codigo2.py COM4 4 0 1234")
        sys.exit(1)

    print(f"Ejecutando con: puerto={port}, esclavo={slave_id}, registro=0x{register_address:04X}, valor={valor}\n")
    write_pymodbus(port, slave_id, register_address, valor)
