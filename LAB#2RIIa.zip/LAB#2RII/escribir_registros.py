import minimalmodbus
import sys
import time

def write_modbus(port, slave_id, register_address, value, num_decimals=0, function_code=6):
    """
    Escribe un valor en un Holding Register del PMAC770 via Modbus RTU.
    Usa FC6 (Write Single Register) por defecto — correcto para escritura individual.
    """
    # CORRECCIÓN: validar rango de registro de 16 bits
    if not (0 <= value <= 65535):
        print(f"Error: el valor {value} está fuera del rango Modbus [0 - 65535].")
        sys.exit(1)

    try:
        instrument = minimalmodbus.Instrument(port, slave_id)

        # Configuración del bus RS-485 / PMAC770
        instrument.serial.baudrate = 9600
        instrument.serial.bytesize = 8
        instrument.serial.parity   = minimalmodbus.serial.PARITY_NONE
        instrument.serial.stopbits = 1
        instrument.serial.timeout  = 1
        instrument.mode            = minimalmodbus.MODE_RTU

        print(f"[{time.strftime('%H:%M:%S')}] Puerto {port} — Esclavo {slave_id} — FC{function_code}")

        # Escribir el registro
        # CORRECCIÓN: El PMAC770 NO soporta FC6. Solo soporta FC16 (0x10) para escritura.
        instrument.write_register(register_address, value, num_decimals, functioncode=16)
        print(f"[{time.strftime('%H:%M:%S')}] [ÉXITO] Valor {value} escrito en registro 0x{register_address:04X} ({register_address}).")

    except minimalmodbus.NoResponseError:
        print(f"[{time.strftime('%H:%M:%S')}] El esclavo {slave_id} no respondió. Verifica conexión y dirección.")
        sys.exit(1)
    except minimalmodbus.IllegalRequestError as e:
        print(f"[{time.strftime('%H:%M:%S')}] El esclavo rechazó la escritura (registro de solo lectura o inválido): {e}")
        sys.exit(1)
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] Error al escribir en el registro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Valores por defecto según tu setup: COM4, esclavo 4
    port             = sys.argv[1] if len(sys.argv) > 1 else "COM4"
    slave_id         = int(sys.argv[2]) if len(sys.argv) > 2 else 4

    if len(sys.argv) < 5:
        print("Uso: python escribir_registros.py [PUERTO] [ID_ESCLAVO] <DIRECCION_REGISTRO> <VALOR>")
        print("Ejemplo: python escribir_registros.py COM4 4 0x0100 1234")
        sys.exit(1)

    # Parsear dirección — acepta hex (0x..) y decimal
    reg_str = sys.argv[3]
    if reg_str.lower().startswith('0x'):
        direccion_registro = int(reg_str, 16)
    else:
        direccion_registro = int(reg_str)

    valor = int(sys.argv[4])

    print(f"Ejecutando con: puerto={port}, esclavo={slave_id}, registro=0x{direccion_registro:04X}, valor={valor}")
    print(f"Función Modbus: FC16 (Write Multiple Registers)\n")

    # CORRECCIÓN: usar FC16 ya que PMAC770 no soporta FC6
    write_modbus(port, slave_id, direccion_registro, valor, function_code=16)
