import minimalmodbus
import sys
import time

def read_modbus(port, slave_id, register_address_start, count=10):
    """
    Lee bloques de registros continuamente desde el PMAC770.
    El PMAC770 usa SOLO Función 3 (Holding Registers) — no soporta Fn4.
    """
    # Inicializar instrument ANTES del try para que el scope sea claro
    instrument = None
    try:
        instrument = minimalmodbus.Instrument(port, slave_id)

        # Parámetros del bus RS-485 / PMAC770
        instrument.serial.baudrate = 9600
        instrument.serial.bytesize = 8
        instrument.serial.parity   = minimalmodbus.serial.PARITY_NONE
        instrument.serial.stopbits = 1
        instrument.serial.timeout  = 1
        instrument.mode            = minimalmodbus.MODE_RTU

        print(f"[{time.strftime('%H:%M:%S')}] Puerto {port} abierto — Esclavo {slave_id} a 9600 bps.")
        print(f"[{time.strftime('%H:%M:%S')}] Leyendo {count} Holding Registers desde 0x{register_address_start:04X}. Ctrl+C para detener.\n")

    except Exception as e:
        print(f"Error al configurar el puerto {port}: {e}")
        sys.exit(1)

    while True:
        try:
            # CORRECCIÓN: PMAC770 solo soporta Función 3 (Holding Registers)
            # Fn4 (Input Registers) fue ELIMINADO — causa Illegal Function en el PMAC770
            holding_regs = instrument.read_registers(
                register_address_start, count, functioncode=3
            )

            print(f"[{time.strftime('%H:%M:%S')}] --- Holding Registers (Fn3) — 0x{register_address_start:04X} a 0x{register_address_start + count - 1:04X} ---")
            for i, valor in enumerate(holding_regs):
                addr = register_address_start + i
                print(f"   Reg 0x{addr:04X} ({addr:>4}): {valor:>6}  (0x{valor:04X})")
            print("-" * 60)

        except minimalmodbus.NoResponseError:
            print(f"[{time.strftime('%H:%M:%S')}] Esclavo {slave_id} no responde. Verifica conexión RS-485 y dirección.")
        except minimalmodbus.InvalidResponseError:
            print(f"[{time.strftime('%H:%M:%S')}] Respuesta inválida — ruido en la línea RS-485.")
        except OSError:
            print(f"[{time.strftime('%H:%M:%S')}] El puerto {port} se cerró inesperadamente.")
            break
        except minimalmodbus.IllegalRequestError as e:
            # PMAC770 rechazó la consulta — registro no existe en esa dirección
            print(f"[{time.strftime('%H:%M:%S')}] El esclavo rechazó la consulta (registro inválido o count demasiado grande): {e}")
        except KeyboardInterrupt:
            print(f"\n[{time.strftime('%H:%M:%S')}] Lectura detenida por el usuario.")
            break
        except Exception as e:
            print(f"[{time.strftime('%H:%M:%S')}] Error: {e}")

        time.sleep(1)

if __name__ == "__main__":
    # Valores por defecto según tu setup: COM4, esclavo 4, desde 0x0000
    port      = sys.argv[1] if len(sys.argv) > 1 else "COM4"
    slave_id  = int(sys.argv[2]) if len(sys.argv) > 2 else 4
    count     = int(sys.argv[4]) if len(sys.argv) > 4 else 10  # registros a leer

    # Parsear dirección: acepta hex (0x0000) o decimal
    reg_str = sys.argv[3] if len(sys.argv) > 3 else "0"
    if reg_str.lower().startswith('0x'):
        direccion_registro = int(reg_str, 16)
    else:
        try:
            direccion_registro = int(reg_str)
        except ValueError:
            direccion_registro = int(reg_str, 16)

    print(f"Uso: python leer_registros.py [PUERTO] [ID_ESCLAVO] [DIR_INICIO] [CANT_REGS]")
    print(f"Ejecutando con: puerto={port}, esclavo={slave_id}, inicio=0x{direccion_registro:04X}, count={count}\n")

    read_modbus(port, slave_id, direccion_registro, count)