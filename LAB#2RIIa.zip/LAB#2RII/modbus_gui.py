import tkinter as tk
from tkinter import ttk, messagebox
import minimalmodbus
import serial
import serial.tools.list_ports
import threading
import time
from datetime import datetime
import collections

# Importaciones para gráficos de matplotlib dentro de Tkinter
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.dates as mdates

class ModbusApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Terminal Modbus Interactiva - PMAC770 Lector")
        self.root.geometry("1150x700")
        self.root.configure(bg="#f4f4f4")
        
        # Configuración Modbus
        self.instrument = None
        self.is_polling = False
        self.poll_thread = None
        
        # Datos para gráfico (Máximo 100 puntos en pantalla)
        self.max_points = 50
        self.x_data = collections.deque(maxlen=self.max_points)
        self.y_read_data = collections.deque(maxlen=self.max_points)
        self.y_write_points_x = []
        self.y_write_points_y = []
        
        self.create_widgets()
        self.refresh_ports()
        
    def create_widgets(self):
        # --- Estilos ---
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TFrame", background="#f4f4f4")
        style.configure("TLabel", background="#f4f4f4", font=("Segoe UI", 9))
        style.configure("Header.TLabel", font=("Segoe UI", 11, "bold"), foreground="#2c3e50")
        
        # Main Layout
        main_pane = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_pane.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        left_frame = ttk.Frame(main_pane, width=350)
        right_frame = ttk.Frame(main_pane)
        main_pane.add(left_frame, weight=0)
        main_pane.add(right_frame, weight=1)
        
        # ==========================================
        # PANEL IZQUIERDO: Configuración y Log
        # ==========================================
        
        # 1. Configuración de Conexión Serial
        conn_lf = ttk.LabelFrame(left_frame, text=" 🔌 Configuración Serial ")
        conn_lf.pack(fill=tk.X, pady=5)
        
        # Port
        ttk.Label(conn_lf, text="Puerto COM:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.cb_ports = ttk.Combobox(conn_lf, width=15)
        self.cb_ports.grid(row=0, column=1, padx=5, pady=5)
        btn_refresh = ttk.Button(conn_lf, text="🔄", width=3, command=self.refresh_ports)
        btn_refresh.grid(row=0, column=2, padx=2)
        
        # Baudrate
        ttk.Label(conn_lf, text="Baudios:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.cb_baud = ttk.Combobox(conn_lf, width=15, values=["2400", "4800", "9600", "19200", "38400", "115200"])
        self.cb_baud.set("9600")
        self.cb_baud.grid(row=1, column=1, columnspan=2, sticky="w", padx=5, pady=5)
        
        # Parity
        ttk.Label(conn_lf, text="Paridad (Parity):").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        self.cb_parity = ttk.Combobox(conn_lf, width=15, values=["None", "Even", "Odd"])
        self.cb_parity.set("None")
        self.cb_parity.grid(row=2, column=1, columnspan=2, sticky="w", padx=5, pady=5)
        
        # Bytesize & Stopbits
        ttk.Label(conn_lf, text="Data Bits:").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        self.cb_bytesize = ttk.Combobox(conn_lf, width=15, values=["7", "8"])
        self.cb_bytesize.set("8")
        self.cb_bytesize.grid(row=3, column=1, columnspan=2, sticky="w", padx=5, pady=5)
        
        ttk.Label(conn_lf, text="Stop Bits:").grid(row=4, column=0, sticky="w", padx=5, pady=5)
        self.cb_stopbits = ttk.Combobox(conn_lf, width=15, values=["1", "2"])
        self.cb_stopbits.set("1")
        self.cb_stopbits.grid(row=4, column=1, columnspan=2, sticky="w", padx=5, pady=5)
        
        # Timeout
        ttk.Label(conn_lf, text="Timeout (seg):").grid(row=5, column=0, sticky="w", padx=5, pady=5)
        self.entry_timeout = ttk.Entry(conn_lf, width=18)
        self.entry_timeout.insert(0, "0.5")
        self.entry_timeout.grid(row=5, column=1, columnspan=2, sticky="w", padx=5, pady=5)

        # Boton Conectar
        self.btn_connect = ttk.Button(conn_lf, text="Conectar", command=self.toggle_connection)
        self.btn_connect.grid(row=6, column=0, columnspan=3, pady=10)

        # 2. Configuración Modbus Operativa
        modbus_lf = ttk.LabelFrame(left_frame, text=" ⚙️ Modbus Operativo ")
        modbus_lf.pack(fill=tk.X, pady=5)
        
        ttk.Label(modbus_lf, text="Slave ID:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.entry_slave = ttk.Entry(modbus_lf, width=10)
        self.entry_slave.insert(0, "4")
        self.entry_slave.grid(row=0, column=1, sticky="w", padx=5, pady=5)
        
        ttk.Label(modbus_lf, text="Dirección (Offset):").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.entry_addr = ttk.Entry(modbus_lf, width=10)
        self.entry_addr.insert(0, "5003") # Default PMAC modbus address config
        self.entry_addr.grid(row=1, column=1, sticky="w", padx=5, pady=5)

        # Funcion
        ttk.Label(modbus_lf, text="Función Lectura:").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        self.cb_func_read = ttk.Combobox(modbus_lf, width=15, values=["3 (Holding Regs)", "4 (Input Regs)"])
        self.cb_func_read.set("3 (Holding Regs)")
        self.cb_func_read.grid(row=2, column=1, sticky="w", padx=5, pady=5)
        
        # Poll Rate
        ttk.Label(modbus_lf, text="Scan Rate (ms):").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        self.entry_scan = ttk.Entry(modbus_lf, width=10)
        self.entry_scan.insert(0, "1000")
        self.entry_scan.grid(row=3, column=1, sticky="w", padx=5, pady=5)

        # Toggle Polling
        self.btn_poll = ttk.Button(modbus_lf, text="▶ Iniciar Lectura Continua", command=self.toggle_polling, state=tk.DISABLED)
        self.btn_poll.grid(row=4, column=0, columnspan=2, pady=5, padx=5, sticky="we")

        # Separador
        ttk.Separator(modbus_lf, orient=tk.HORIZONTAL).grid(row=5, column=0, columnspan=2, sticky="we", pady=5)
        
        # Escribir
        ttk.Label(modbus_lf, text="Valor a escribir:").grid(row=6, column=0, sticky="w", padx=5, pady=5)
        self.entry_val = ttk.Entry(modbus_lf, width=10)
        self.entry_val.insert(0, "5")
        self.entry_val.grid(row=6, column=1, sticky="w", padx=5, pady=5)
        
        self.btn_write = ttk.Button(modbus_lf, text="✏️ Escribir Valor (FC16)", command=self.write_register, state=tk.DISABLED)
        self.btn_write.grid(row=7, column=0, columnspan=2, pady=5, padx=5, sticky="we")

        # 3. Consola de Logs
        log_lf = ttk.LabelFrame(left_frame, text=" 📝 Terminal de Eventos ")
        log_lf.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.txt_log = tk.Text(log_lf, height=10, width=40, font=("Consolas", 8), bg="#2c3e50", fg="#ecf0f1")
        self.txt_log.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=2, pady=2)
        scrollbar = ttk.Scrollbar(log_lf, command=self.txt_log.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.txt_log.config(yscrollcommand=scrollbar.set)

        # ==========================================
        # PANEL DERECHO: Gráfico
        # ==========================================
        grafica_lf = ttk.LabelFrame(right_frame, text=" 📈 Visualización en Tiempo Real ")
        grafica_lf.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Configurar Matplotlib
        self.fig, self.ax = plt.subplots(figsize=(7, 5), dpi=100)
        self.ax.set_title("Mediciones Modbus")
        self.ax.set_xlabel("Tiempo")
        self.ax.set_ylabel("Valor")
        self.ax.grid(True, linestyle="--", alpha=0.7)
        self.fig.tight_layout(pad=3.0)
        
        # Linea de serie
        self.line_read, = self.ax.plot([], [], marker='o', color='#3498db', label="Lectura", linewidth=2)
        self.scatter_write = self.ax.scatter([], [], color='#e74c3c', s=100, marker='*', label="Escritura", zorder=5)
        self.ax.legend(loc='upper right')

        self.canvas = FigureCanvasTkAgg(self.fig, master=grafica_lf)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def refresh_ports(self):
        ports = serial.tools.list_ports.comports()
        port_list = [p.device for p in ports]
        self.cb_ports['values'] = port_list
        if port_list:
            self.cb_ports.set(port_list[0])
            
    def log(self, mensaje, is_error=False):
        timestamp = datetime.now().strftime("%H:%M:%S")
        prefix = "❌" if is_error else "✓"
        line = f"[{timestamp}] {prefix} {mensaje}\n"
        
        self.txt_log.configure(state='normal')
        self.txt_log.insert(tk.END, line)
        self.txt_log.see(tk.END)
        self.txt_log.configure(state='disabled')

    def toggle_connection(self):
        if self.instrument is None:
            # CONECTAR
            port = self.cb_ports.get()
            slave_id = int(self.entry_slave.get())
            baud = int(self.cb_baud.get())
            b_size = int(self.cb_bytesize.get())
            stop_b = int(self.cb_stopbits.get())
            par_str = self.cb_parity.get()
            timeout = float(self.entry_timeout.get())
            
            parity = serial.PARITY_NONE
            if par_str == "Even": parity = serial.PARITY_EVEN
            if par_str == "Odd": parity = serial.PARITY_ODD
                
            try:
                self.instrument = minimalmodbus.Instrument(port, slave_id)
                self.instrument.serial.baudrate = baud
                self.instrument.serial.bytesize = b_size
                self.instrument.serial.parity = parity
                self.instrument.serial.stopbits = stop_b
                self.instrument.serial.timeout = timeout
                self.instrument.mode = minimalmodbus.MODE_RTU
                
                self.btn_connect.configure(text="Desconectar")
                self.log(f"Conectado a {port} a {baud}bps.")
                
                # Activar botones operativos
                self.btn_poll.configure(state=tk.NORMAL)
                self.btn_write.configure(state=tk.NORMAL)
                
            except Exception as e:
                self.log(f"Error puerto: {str(e)}", True)
                messagebox.showerror("Error de Conexión", str(e))
        else:
            # DESCONECTAR
            if self.is_polling:
                self.toggle_polling()
            
            try:
                self.instrument.serial.close()
            except: pass
            
            self.instrument = None
            self.btn_connect.configure(text="Conectar")
            self.btn_poll.configure(state=tk.DISABLED)
            self.btn_write.configure(state=tk.DISABLED)
            self.log("Puerto desconectado.")

    def toggle_polling(self):
        if not self.is_polling:
            self.is_polling = True
            self.btn_poll.configure(text="⏹ Detener Lectura")
            
            # Limpiar gráficos anteriores si cambiamos
            self.x_data.clear()
            self.y_read_data.clear()
            self.y_write_points_x.clear()
            self.y_write_points_y.clear()
            self.ax.clear()
            self.ax.set_title("Mediciones Modbus")
            self.ax.grid(True, linestyle="--", alpha=0.7)
            self.line_read, = self.ax.plot([], [], marker='o', color='#3498db', label="Lectura")
            self.scatter_write = self.ax.scatter([], [], color='#e74c3c', s=100, marker='*', zorder=5, label="Escritura")
            self.ax.legend(loc='upper right')
            
            # Correr en un hilo separado
            self.poll_thread = threading.Thread(target=self.polling_task, daemon=True)
            self.poll_thread.start()
            self.log("Iniciando escaneo continuo...")
        else:
            self.is_polling = False
            self.btn_poll.configure(text="▶ Iniciar Lectura Continua")
            self.log("Escaneo detenido.")

    def polling_task(self):
        while self.is_polling and self.instrument:
            try:
                addr = int(self.entry_addr.get().strip(), 0)
                scan_ms = int(self.entry_scan.get())
                func_str = self.cb_func_read.get()
                func_code = 3 if "3" in func_str else 4
                
                # Para evitar conflictos, actualizamos el esclavo por si lo cambiaron en la GUI
                slave_id = int(self.entry_slave.get())
                if self.instrument.address != slave_id:
                    self.instrument.address = slave_id
                
                # Realizar lectura Modbus
                try:
                    val = self.instrument.read_register(addr, 0, functioncode=func_code)
                    
                    # Grabar dato
                    now = datetime.now()
                    self.root.after(0, self.update_graph_data, now, val)
                    self.root.after(0, self.log, f"Lectura (Reg {addr}): {val}")
                    
                except minimalmodbus.NoResponseError:
                    self.root.after(0, self.log, f"Timeout - Esclavo {slave_id} no responde (Dir: {addr})", True)
                except Exception as ex:
                    self.root.after(0, self.log, f"Error lectura: {str(ex)}", True)
                
            except ValueError:
                self.root.after(0, self.log, "Parámetros inválidos numéricos.", True)
                time.sleep(1)
                
            # Dormir scan_ms convertido a segundos
            time.sleep(scan_ms / 1000.0)

    def write_register(self):
        if not self.instrument:
            return
            
        try:
            addr = int(self.entry_addr.get().strip(), 0)
            val = int(self.entry_val.get().strip(), 0)
            slave_id = int(self.entry_slave.get())
            
            if self.instrument.address != slave_id:
                self.instrument.address = slave_id
                
            self.log(f"Enviando escritura... Esclavo {slave_id}, Reg {addr}, Valor {val}")
            
            # PMAC770 requiere FC16 para escribir aunque sea 1 solo registro
            self.instrument.write_register(addr, val, functioncode=16)
            self.log(f"Éxito: Escrito {val} en registro {addr}.")
            
            # Reflejar el evento de escritura en el gráfico inmediatamente (si estamos escaneando)
            if self.is_polling and len(self.x_data) > 0:
                self.y_write_points_x.append(datetime.now())
                self.y_write_points_y.append(val)
                self.refresh_canvas()
                
        except minimalmodbus.NoResponseError:
            self.log(f"Timeout al escribir en Esclavo {slave_id}.", True)
        except minimalmodbus.IllegalRequestError:
            self.log("Error de esclavo: Illegal Function o Data Address.", True)
        except Exception as ex:
            self.log(f"Error escritura: {str(ex)}", True)

    def update_graph_data(self, dt, y_val):
        self.x_data.append(dt)
        self.y_read_data.append(y_val)
        self.refresh_canvas()
        
    def refresh_canvas(self):
        if len(self.x_data) > 0:
            self.line_read.set_data(self.x_data, self.y_read_data)
            
            if len(self.y_write_points_x) > 0:
                self.scatter_write.set_offsets(list(zip([mdates.date2num(d) for d in self.y_write_points_x], self.y_write_points_y)))
                
            self.ax.relim()
            self.ax.autoscale_view()
            
            # Formato de tiempo para el Eje X
            self.ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
            for label in self.ax.get_xticklabels():
                label.set_rotation(45)
            self.fig.autofmt_xdate()
            
            self.canvas.draw_idle()

if __name__ == "__main__":
    root = tk.Tk()
    app = ModbusApp(root)
    root.mainloop()
